#!/bin/bash
$projdir = pwd
cd $projdir



